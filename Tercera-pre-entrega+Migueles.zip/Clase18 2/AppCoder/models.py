from django.db import models

# Create your models here.

class Curso(models.Model):

    nombre = models.CharField(max_length=40)
    camada = models.IntegerField()

class Alumnos(models.Model):
    nombre_alumno = models.CharField(max_length=40)
    apellido_alumno = models.CharField(max_length=40)

class Profesores(models.Model):
    nombre_profesor = models.CharField(max_length=40)
    apellido_profesor = models.CharField(max_length=40)
